const http = require('http'); 
const server = http.createServer(
function(req, res) {
    console.log(req)    
    res.writeHead(200, {'Content-Type': 'text/plain'});
    res.end('Hello BCA! Server is running!');
});
// ← LISTEN: Start server on port 3000
server.listen(3000, function() {       
console.log('Server running at http://localhost:3000/');
})