console.log("hello world") 
let x=10;
console.log(x);
let y=20.01;
console.log(y);
console.log(typeof(x));
console.log(y);
var arr=[1,2,3];
console.log(arr);
var arr1=[1,2,3,4,"hello"];
console.log(typeof(arr1));
arr1=[1,2,3,4]
console.log(arr1[0]);
arr1=[1,2,3,4]
console.log(arr1[-1]);
let a=undefined;
let std1={std_name:"falak",
         reg_no:1234,
        hobbies:['h1','h2']
};

console.log("student 1 name:",std1,std1.std_name);
//function 


function add(x,y){
    
   return x+y

}
add(7,8)
//function wihtout name

console.log(function(x,y){
return x+y}(2,3));
//arrow function
console.log((x,y)=>{return x+y});
