const express = require("express");
const app = express();

app.use(express.json())//middle ware
//route

let students = [{ id: 1, name: "Rahul", course: "BCA" },
    { id: 2, name: "Rohit", course: "BCA" }]
//creating dummy data

//implementing get method

app.get("/students",(req,res)=>{
    //logic
    res.json(students);
})
//get method for specific students

app.get('/students/:id',(req,res)=>{
    //logic
    //url  - res
    let idurl =  req.params.id

    for(i=1;i<students.length;i++){
       if (students[i].id == idurl){
        res.status(200).json(students[i]) //success
       }
    }
    //error
    res.send(404).json({msg:"students not found"})
})
app.listen(3000, () => {
console.log("Server running on port 3000");
})//start server on port number 3000