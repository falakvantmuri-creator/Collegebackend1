const express = require('express');
const app = express();

let stud = {route:'/students',studlist:['🐵stud1','🐵stud2','🐵stud3', '🐵stud4'],message:"Take this list of studs!"}; 
// route home page
app.get('/', (req, res) => {
    res.send("🏠 Student Info!");
});

app.get('/about', (req, res) => {
    res.send('ℹ️information!');
});

app.get('/regno', (req, res) => {
    res.send("☎️ Registration Number!");
});

app.get('/index', (req, res) => {
    res.status(404).send("⚠️ Page not found!");
});

app.get('/found', (req, res) => {
    res.status(404).json({msg:"⚠️ Page not found!"});
});

app.get('/students', (req, res) => {
    res.json(stud);
});

// single Route handling multiple url's 
app.get('/students/:id', (req, res) => {
    let sid = req.params.id;
    res.json({studid:sid});
});

app.listen(8080, () => {
    console.log('Server is running at port 8080!');
});